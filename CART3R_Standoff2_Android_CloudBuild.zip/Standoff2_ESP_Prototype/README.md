# CART3R Standoff 2 Style Skeleton ESP Prototype

This is an Android Studio **visual demo**, not a working cheat and not connected to Standoff 2.
It draws fictional skeleton targets inside its own app so you can test the interface safely.

## Open
1. Extract the ZIP.
2. Open the `Standoff2_ESP_Prototype` folder in Android Studio.
3. Let Gradle sync.
4. Run on an Android device or emulator.

## Build an APK
In Android Studio choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

The app does not read game memory, inspect game traffic, or interact with anti-cheat systems.

## Build from your phone with GitHub Actions
1. Upload the contents of this project to a GitHub repository on the `main` branch.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK**, then tap **Run workflow** if it has not started automatically.
4. When the run finishes, open it and download the `CART3R-ESP-Demo-APK` artifact.
5. Extract the downloaded artifact ZIP to get `app-debug.apk`.
