package com.cart3r.esp

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var demoView: SkeletonDemoView
    private lateinit var toggle: Button
    private var enabled = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(8, 8, 10))
            setPadding(18, 22, 18, 18)
        }

        val title = TextView(this).apply {
            text = "CART3R  /  SKELETON ESP DEMO"
            setTextColor(Color.rgb(255, 55, 75))
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 14)
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "LOCAL VISUAL SIMULATION  •  NOT CONNECTED TO STANDOFF 2"
            setTextColor(Color.LTGRAY)
            textSize = 10f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 12)
        }
        root.addView(subtitle)

        demoView = SkeletonDemoView(this)
        root.addView(demoView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        toggle = Button(this).apply {
            text = "ESP: ON"
            setOnClickListener {
                enabled = !enabled
                text = if (enabled) "ESP: ON" else "ESP: OFF"
                demoView.showSkeletons = enabled
                demoView.invalidate()
            }
        }
        root.addView(toggle, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        val note = TextView(this).apply {
            text = "Demo targets are drawn locally for UI testing. No game memory, network, or anti-cheat interaction."
            setTextColor(Color.GRAY)
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding(8, 12, 8, 4)
        }
        root.addView(note)

        setContentView(root)
    }
}

class SkeletonDemoView(context: android.content.Context) : View(context) {
    var showSkeletons = true
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 45, 65)
        strokeWidth = 4f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val head = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 45, 65)
        strokeWidth = 3.5f
        style = Paint.Style.STROKE
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 30f
        typeface = android.graphics.Typeface.create("sans-serif-medium", 1)
    }
    private val panel = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(20, 20, 25)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(12, 13, 17))
        val w = width.toFloat()
        val h = height.toFloat()

        // Decorative target grid
        val grid = Paint().apply {
            color = Color.rgb(32, 34, 42)
            strokeWidth = 1f
        }
        for (x in 0..width step 48) canvas.drawLine(x.toFloat(), 0f, x.toFloat(), h, grid)
        for (y in 0..height step 48) canvas.drawLine(0f, y.toFloat(), w, y.toFloat(), grid)

        canvas.drawRoundRect(18f, 18f, w - 18f, 72f, 12f, 12f, panel)
        canvas.drawText("TRAINING OVERLAY PREVIEW", 34f, 53f, label.apply { textSize = 22f; color = Color.LTGRAY })

        if (!showSkeletons) {
            label.textSize = 30f
            label.color = Color.GRAY
            canvas.drawText("SKELETON ESP DISABLED", 34f, h / 2f, label)
            return
        }

        drawPlayer(canvas, w * 0.32f, h * 0.48f, 0.88f, "PLAYER 01  •  12m")
        drawPlayer(canvas, w * 0.70f, h * 0.62f, 0.68f, "PLAYER 02  •  24m")
    }

    private fun drawPlayer(c: Canvas, cx: Float, cy: Float, s: Float, name: String) {
        val p = line
        fun pt(x: Float, y: Float) = Pair(cx + x * s, cy + y * s)
        fun bone(a: Pair<Float, Float>, b: Pair<Float, Float>) {
            c.drawLine(a.first, a.second, b.first, b.second, p)
        }

        val headY = cy - 112f * s
        c.drawCircle(cx, headY, 19f * s, head)
        val neck = pt(0f, -88f)
        val chest = pt(0f, -42f)
        val hip = pt(0f, 28f)
        val ls = pt(-34f, -72f); val rs = pt(34f, -72f)
        val le = pt(-55f, -25f); val re = pt(55f, -25f)
        val lh = pt(-62f, 18f); val rh = pt(62f, 18f)
        val lk = pt(-23f, 88f); val rk = pt(23f, 88f)
        val lf = pt(-30f, 145f); val rf = pt(30f, 145f)

        bone(pt(0f, -93f), chest)
        bone(chest, hip)
        bone(chest, ls); bone(ls, le); bone(le, lh)
        bone(chest, rs); bone(rs, re); bone(re, rh)
        bone(hip, lk); bone(lk, lf)
        bone(hip, rk); bone(rk, rf)

        val textPaint = Paint(label).apply { textSize = 23f; color = Color.WHITE }
        c.drawText(name, cx - 82f * s, headY - 34f * s, textPaint)
    }
}
